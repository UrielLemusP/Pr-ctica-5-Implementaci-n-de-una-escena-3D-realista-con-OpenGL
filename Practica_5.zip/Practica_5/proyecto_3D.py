import os
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math

# -------------------------------------------------------------------
# Proyecto 3D: Visualizador de figuras 3D con OpenGL y Pygame
# Este script permite visualizar diferentes figuras 3D (cubo, pirámide,
# esfera, cilindro y superelipsoide) con opciones de transformación,
# iluminación y texturizado. El usuario puede interactuar mediante
# teclado para mover, rotar, escalar las figuras y cambiar configuraciones.
# -------------------------------------------------------------------

# -------------------- Clase de Estado del Programa --------------------
class Estado:
    """
    Clase que mantiene el estado actual del programa, incluyendo la figura
    seleccionada, transformaciones aplicadas, opciones de iluminación,
    texturizado y proyección, así como la posición de la fuente de luz.
    """

    def __init__(self):
        # Figura actualmente seleccionada para mostrar
        self.figura_actual = None
        # Indica si el programa está mostrando el menú principal
        self.esta_en_menu = True
        # Ángulos de rotación en grados para los ejes X, Y, Z
        self.rotacion = [0, 0, 0]
        # Vector de traslación en los ejes X, Y, Z (Z negativo para alejar)
        self.traslacion = [0, 0, -5]
        # Escala en los ejes X, Y, Z
        self.escala = [1, 1, 1]
        # Indica si se debe usar textura en la figura
        self.usa_textura = True
        # Indica si se debe usar iluminación en la escena
        self.usa_iluminacion = True
        # Indica si la proyección es perspectiva (True) u ortogonal (False)
        self.proyeccion_perspectiva = True
        # Posición de la fuente de luz (x, y, z, w)
        self.posicion_luz = [5, 0, 0, 1]
        # Componentes de luz ambiental (RGBA)
        self.luz_ambiental = [0.2, 0.2, 0.2, 1]
        # Componentes de luz difusa (RGBA)
        self.luz_difusa = [0.5, 0.5, 0.5, 1]
        # Componentes de luz especular (RGBA)
        self.luz_especular = [1.0, 1.0, 1.0, 1]

    def seleccionar_figura(self, figura):
        """
        Selecciona la figura a mostrar y carga la textura correspondiente.
        Cambia el estado para salir del menú.
        """
        self.figura_actual = figura
        self.esta_en_menu = False
        # Obtiene la ruta absoluta del script actual
        ruta_script = os.path.dirname(os.path.abspath(__file__))
        # Construye la ruta de la textura según la figura seleccionada
        ruta_textura = os.path.join(ruta_script, 'texturas', f'{figura}.jpg')
        # Inicializa la textura para la figura
        inicializar_textura(ruta_textura)

    def procesar_tecla(self, tecla):
        """
        Procesa la tecla presionada para modificar el estado:
        - Movimiento de traslación con flechas
        - Rotación con WASD y QE
        - Escalado con + y -
        - Alternar textura, iluminación y proyección
        - Mover la fuente de luz con JK
        """
        # Salir al menú principal
        if tecla == K_ESCAPE:
            self.esta_en_menu = True
        # Traslación en X
        elif tecla == K_LEFT:
            self.traslacion[0] -= 0.1
        elif tecla == K_RIGHT:
            self.traslacion[0] += 0.1
        # Traslación en Y
        elif tecla == K_UP:
            self.traslacion[1] += 0.1
        elif tecla == K_DOWN:
            self.traslacion[1] -= 0.1
        # Rotación en X
        elif tecla == K_w:
            self.rotacion[0] += 5
        elif tecla == K_s:
            self.rotacion[0] -= 5
        # Rotación en Y
        elif tecla == K_a:
            self.rotacion[1] += 5
        elif tecla == K_d:
            self.rotacion[1] -= 5
        # Rotación en Z
        elif tecla == K_q:
            self.rotacion[2] += 5
        elif tecla == K_e:
            self.rotacion[2] -= 5
        # Escalado uniforme positivo
        elif tecla in (K_EQUALS, K_KP_PLUS):
            self.escala = [s + 0.1 for s in self.escala]
        # Escalado uniforme negativo (con límite mínimo)
        elif tecla in (K_MINUS, K_KP_MINUS):
            self.escala = [max(0.1, s - 0.1) for s in self.escala]
        # Alternar uso de textura
        elif tecla == K_t:
            self.usa_textura = not self.usa_textura
        # Alternar uso de iluminación
        elif tecla == K_l:
            self.usa_iluminacion = not self.usa_iluminacion
        # Alternar tipo de proyección
        elif tecla == K_p:
            self.proyeccion_perspectiva = not self.proyeccion_perspectiva
        # Mover fuente de luz en X
        elif tecla == K_j:
            self.posicion_luz[0] -= 0.5
        elif tecla == K_k:
            self.posicion_luz[0] += 0.5

    def configurar_proyeccion(self):
        """
        Configura la matriz de proyección según el tipo seleccionado:
        - Perspectiva con gluPerspective
        - Ortogonal con glOrtho
        """
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        if self.proyeccion_perspectiva:
            gluPerspective(45, 800 / 600, 0.1, 50.0)
        else:
            glOrtho(-5, 5, -5, 5, 0.1, 50.0)
        glMatrixMode(GL_MODELVIEW)

# -------------------- Transformaciones --------------------
def aplicar_transformaciones(estado):
    """
    Aplica las transformaciones de traslación, escala y rotación
    a la figura según el estado actual.
    """
    glTranslatef(*estado.traslacion)
    glScalef(*estado.escala)
    glRotatef(estado.rotacion[0], 1, 0, 0)
    glRotatef(estado.rotacion[1], 0, 1, 0)
    glRotatef(estado.rotacion[2], 0, 0, 1)

def reiniciar_transformaciones():
    """
    Reinicia la matriz de modelo a la identidad para eliminar
    transformaciones previas.
    """
    glLoadIdentity()

# -------------------- Iluminación --------------------
def configurar_luz(estado):
    """
    Configura la iluminación de la escena activando la luz GL_LIGHT0
    y estableciendo sus propiedades según el estado.
    """
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glLightfv(GL_LIGHT0, GL_POSITION, estado.posicion_luz)
    glLightfv(GL_LIGHT0, GL_AMBIENT, estado.luz_ambiental)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, estado.luz_difusa)
    glLightfv(GL_LIGHT0, GL_SPECULAR, estado.luz_especular)

def desactivar_luz():
    """
    Desactiva la iluminación y la luz GL_LIGHT0.
    """
    glDisable(GL_LIGHTING)
    glDisable(GL_LIGHT0)

# -------------------- Texturas --------------------
id_textura = None  # Identificador global para la textura cargada

def inicializar_textura(ruta):
    """
    Carga una imagen desde la ruta especificada y la convierte en
    una textura OpenGL, configurando sus parámetros.
    """
    global id_textura
    try:
        superficie = pygame.image.load(ruta)
    except pygame.error:
        print(f'Error al cargar la textura: {ruta}')
        return
    datos = pygame.image.tostring(superficie, 'RGB', True)
    ancho, alto = superficie.get_size()
    id_textura = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, id_textura)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, ancho, alto, 0, GL_RGB, GL_UNSIGNED_BYTE, datos)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)

def activar_textura():
    """
    Activa la textura cargada para que se aplique en el renderizado.
    """
    if id_textura:
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, id_textura)

def desactivar_textura():
    """
    Desactiva el uso de texturas en el renderizado.
    """
    glDisable(GL_TEXTURE_2D)

# -------------------- Dibujar Figuras --------------------
def dibujar_cubo():
    """
    Dibuja un cubo usando vértices y caras definidas, aplicando
    coordenadas de textura para cada vértice.
    """
    vertices = [
        (-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
        (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)
    ]
    caras = [
        (0, 1, 2, 3), (4, 5, 6, 7),
        (0, 4, 7, 3), (1, 5, 6, 2),
        (3, 2, 6, 7), (0, 1, 5, 4)
    ]
    glBegin(GL_QUADS)
    for cara in caras:
        for vertice in cara:
            # Asigna coordenadas de textura normalizadas entre 0 y 1
            glTexCoord2f((vertices[vertice][0] + 1) / 2, (vertices[vertice][1] + 1) / 2)
            glVertex3fv(vertices[vertice])
    glEnd()

def dibujar_piramide():
    """
    Dibuja una pirámide con base cuadrada y caras triangulares,
    aplicando coordenadas de textura.
    """
    vertices = [
        (0, 1, 0), (-1, -1, -1), (1, -1, -1),
        (0, 1, 0), (1, -1, -1), (1, -1, 1),
        (0, 1, 0), (1, -1, 1), (-1, -1, 1),
        (0, 1, 0), (-1, -1, 1), (-1, -1, -1)
    ]
    caras = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (9, 10, 11)]
    glBegin(GL_TRIANGLES)
    for cara in caras:
        for vertice in cara:
            glTexCoord2f((vertices[vertice][0]+1)/2, (vertices[vertice][1]+1)/2)
            glVertex3fv(vertices[vertice])
    glEnd()

    # Dibuja la base cuadrada de la pirámide
    glBegin(GL_QUADS)
    glTexCoord2f(0, 0); glVertex3f(-1, -1, -1)
    glTexCoord2f(1, 0); glVertex3f(1, -1, -1)
    glTexCoord2f(1, 1); glVertex3f(1, -1, 1)
    glTexCoord2f(0, 1); glVertex3f(-1, -1, 1)
    glEnd()

def dibujar_esfera():
    """
    Dibuja una esfera usando gluSphere con textura habilitada.
    """
    esfera = gluNewQuadric()
    gluQuadricTexture(esfera, GL_TRUE)
    gluSphere(esfera, 1, 32, 32)

def dibujar_cilindro():
    """
    Dibuja un cilindro con tapas usando gluCylinder y triángulos
    para las tapas, aplicando coordenadas de textura.
    """
    cilindro = gluNewQuadric()
    gluQuadricTexture(cilindro, GL_TRUE)
    gluCylinder(cilindro, 1, 1, 2, 32, 32)

    # Dibuja la tapa superior del cilindro
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(.5, .5)
    glVertex3f(0, 0, 2)
    for i in range(33):
        angulo = 2 * math.pi * i / 32
        x = math.cos(angulo)
        y = math.sin(angulo)
        glTexCoord2f(x/2 + .5, y/2 + .5)
        glVertex3f(x, y, 2)
    glEnd()

    # Dibuja la tapa inferior del cilindro
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(.5, .5)
    glVertex3f(0, 0, 0)
    for i in range(33):
        angulo = 2 * math.pi * i / 32
        x = math.cos(angulo)
        y = math.sin(angulo)
        glTexCoord2f(x/2 + .5, y/2 + .5)
        glVertex3f(x, y, 0)
    glEnd()

def dibujar_superelipsoide():
    """
    Dibuja un superelipsoide usando puntos calculados con la fórmula
    paramétrica y aplicando coordenadas de textura.
    """
    def super_forma(theta, phi, m, n1, n2, n3):
        a, b, c = 1, 1, 2
        t1 = abs(math.cos(m * theta / 4) / a) ** n2
        t2 = abs(math.sin(m * theta / 4) / b) ** n3
        r = (t1 + t2) ** (-1 / n1)
        x = r * math.cos(theta) * math.cos(phi)
        y = r * math.sin(theta) * math.cos(phi)
        z = r * math.sin(phi)
        return (x, y, z)

    glBegin(GL_POINTS)
    for i in range(200):
        theta = math.pi * (-0.5 + i / 200)
        for j in range(200):
            phi = 2 * math.pi * j / 200
            x, y, z = super_forma(theta, phi, 4, 2, 1.7, 1.7)
            glTexCoord2f((x+1)/2, (y+1)/2)
            glVertex3f(x, y, z)
    glEnd()

# -------------------- Menú Principal y Bucle --------------------
def mostrar_menu():
    """
    Muestra en consola el menú principal con las opciones disponibles
    para seleccionar la figura a visualizar o salir del programa.
    """
    print("MENU PRINCIPAL\n1-Cubo\n2-Pirámide\n3-Esfera\n4-Cilindro\n5-Superelipsoide\n6-Salir")

def main():
    """
    Función principal que inicializa Pygame y OpenGL, configura el estado
    inicial y ejecuta el bucle principal para manejar eventos y renderizar
    las figuras 3D según la interacción del usuario.
    """
    pygame.init()
    pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
    pygame.display.set_caption('Visualizador 3D')
    glEnable(GL_DEPTH_TEST)  # Habilita prueba de profundidad para renderizado 3D correcto
    glEnable(GL_TEXTURE_2D)  # Habilita texturizado 2D
    glEnable(GL_NORMALIZE)   # Normaliza normales para iluminación correcta

    estado = Estado()

    while True:
        for evento in pygame.event.get():
            if evento.type == QUIT:
                pygame.quit()
                return
            if evento.type == KEYDOWN:
                if estado.esta_en_menu:
                    # Selección de figura desde el menú principal
                    if evento.key in (K_1, K_KP1): estado.seleccionar_figura('cubo')
                    elif evento.key in (K_2, K_KP2): estado.seleccionar_figura('piramide')
                    elif evento.key in (K_3, K_KP3): estado.seleccionar_figura('esfera')
                    elif evento.key in (K_4, K_KP4): estado.seleccionar_figura('cilindro')
                    elif evento.key in (K_5, K_KP5): estado.seleccionar_figura('superelipsoide')
                    elif evento.key in (K_6, K_KP6): pygame.quit(); return
                else:
                    # Procesa teclas para transformar la figura o cambiar opciones
                    estado.procesar_tecla(evento.key)

        # Limpia buffers de color y profundidad para nuevo frame
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        # Configura la proyección (perspectiva u ortogonal)
        estado.configurar_proyeccion()

        if estado.esta_en_menu:
            # Muestra el menú en consola si está en modo menú
            mostrar_menu()
        else:
            # Configura iluminación si está habilitada
            if estado.usa_iluminacion:
                configurar_luz(estado)
            else:
                desactivar_luz()

            # Aplica transformaciones a la figura
            aplicar_transformaciones(estado)

            # Activa o desactiva textura según estado
            if estado.usa_textura:
                activar_textura()
            else:
                desactivar_textura()

            # Dibuja la figura seleccionada
            if estado.figura_actual == 'cubo':
                dibujar_cubo()
            elif estado.figura_actual == 'piramide':
                dibujar_piramide()
            elif estado.figura_actual == 'esfera':
                dibujar_esfera()
            elif estado.figura_actual == 'cilindro':
                dibujar_cilindro()
            elif estado.figura_actual == 'superelipsoide':
                dibujar_superelipsoide()

        # Actualiza la pantalla con el nuevo frame renderizado
        pygame.display.flip()
        # Pausa breve para controlar la velocidad del bucle
        pygame.time.wait(10)

if __name__ == '__main__':
    main()
